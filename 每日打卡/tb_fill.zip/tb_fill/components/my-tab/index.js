(global.webpackJsonp = global.webpackJsonp || []).push([ [ "components/my-tab/index" ], {
    290: function(n, e, t) {
        t.r(e);
        var r = t(291), o = t(293);
        for (var a in o) "default" !== a && function(n) {
            t.d(e, n, function() {
                return o[n];
            });
        }(a);
        t(295);
        var c = t(14), u = Object(c.default)(o.default, r.render, r.staticRenderFns, !1, null, "684daf87", null);
        u.options.__file = "src/components/my-tab/index.vue", e.default = u.exports;
    },
    291: function(n, e, t) {
        t.r(e);
        var r = t(292);
        t.d(e, "render", function() {
            return r.render;
        }), t.d(e, "staticRenderFns", function() {
            return r.staticRenderFns;
        });
    },
    292: function(n, e, t) {
        t.r(e), t.d(e, "render", function() {
            return r;
        }), t.d(e, "staticRenderFns", function() {
            return o;
        });
        var r = function() {
            var n = this, e = n.$createElement;
            n._self._c;
        }, o = [];
        r._withStripped = !0;
    },
    293: function(n, e, t) {
        t.r(e);
        var r = t(294), o = t.n(r);
        for (var a in r) "default" !== a && function(n) {
            t.d(e, n, function() {
                return r[n];
            });
        }(a);
        e.default = o.a;
    },
    294: function(n, e, t) {
        (function(n) {
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.default = void 0;
            var t = {
                name: "myTab",
                props: {
                    activeIndex: {
                        default: 0,
                        type: Number
                    }
                },
                methods: {
                    tabTo: function(e) {
                        n.redirectTo({
                            url: e
                        });
                    }
                }
            };
            e.default = t;
        }).call(this, t(1).default);
    },
    295: function(n, e, t) {
        t.r(e);
        var r = t(296), o = t.n(r);
        for (var a in r) "default" !== a && function(n) {
            t.d(e, n, function() {
                return r[n];
            });
        }(a);
        e.default = o.a;
    },
    296: function(n, e, t) {}
} ]), (global.webpackJsonp = global.webpackJsonp || []).push([ "components/my-tab/index-create-component", {
    "components/my-tab/index-create-component": function(n, e, t) {
        t("1").createComponent(t(290));
    }
}, [ [ "components/my-tab/index-create-component" ] ] ]);