(global.webpackJsonp = global.webpackJsonp || []).push([ [ "components/page-foot" ], {
    252: function(n, e, t) {
        t.r(e);
        var o = t(253), r = t(255);
        for (var a in r) "default" !== a && function(n) {
            t.d(e, n, function() {
                return r[n];
            });
        }(a);
        t(257);
        var u = t(14), c = Object(u.default)(r.default, o.render, o.staticRenderFns, !1, null, null, null);
        c.options.__file = "src/components/page-foot.vue", e.default = c.exports;
    },
    253: function(n, e, t) {
        t.r(e);
        var o = t(254);
        t.d(e, "render", function() {
            return o.render;
        }), t.d(e, "staticRenderFns", function() {
            return o.staticRenderFns;
        });
    },
    254: function(n, e, t) {
        t.r(e), t.d(e, "render", function() {
            return o;
        }), t.d(e, "staticRenderFns", function() {
            return r;
        });
        var o = function() {
            var n = this, e = n.$createElement;
            n._self._c;
        }, r = [];
        o._withStripped = !0;
    },
    255: function(n, e, t) {
        t.r(e);
        var o = t(256), r = t.n(o);
        for (var a in o) "default" !== a && function(n) {
            t.d(e, n, function() {
                return o[n];
            });
        }(a);
        e.default = r.a;
    },
    256: function(n, e, t) {
        (function(n) {
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.default = void 0;
            var t = {
                name: "page-foot",
                props: {
                    name: {
                        type: String,
                        default: ""
                    }
                },
                methods: {
                    submit: function() {
                        n.showModal({
                            content: "hello uni-app开源地址为https://github.com/dcloudio/uni-app/tree/master/examples，请在这个开源项目上贡献你的代码",
                            showCancel: !1
                        });
                    }
                }
            };
            e.default = t;
        }).call(this, t(1).default);
    },
    257: function(n, e, t) {
        t.r(e);
        var o = t(258), r = t.n(o);
        for (var a in o) "default" !== a && function(n) {
            t.d(e, n, function() {
                return o[n];
            });
        }(a);
        e.default = r.a;
    },
    258: function(n, e, t) {}
} ]), (global.webpackJsonp = global.webpackJsonp || []).push([ "components/page-foot-create-component", {
    "components/page-foot-create-component": function(n, e, t) {
        t("1").createComponent(t(252));
    }
}, [ [ "components/page-foot-create-component" ] ] ]);