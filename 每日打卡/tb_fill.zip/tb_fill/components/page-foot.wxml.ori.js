function(e,s,r,gg){
var z=gz$gwx_4()
var oTD=_n('view')
_rz(z,oTD,'class',0,e,s,gg)
var xUD=_n('text')
var oVD=_oz(z,1,e,s,gg)
_(xUD,oVD)
_(oTD,xUD)
var fWD=_mz(z,'text',['bindtap',2,'class',1,'data-event-opts',2],[],e,s,gg)
var cXD=_oz(z,5,e,s,gg)
_(fWD,cXD)
_(oTD,fWD)
_(r,oTD)
return r
}