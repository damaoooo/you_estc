function(e,s,r,gg){
var z=gz$gwx_6()
var a4D=_mz(z,'picker',['bindchange',0,'bindcolumnchange',1,'data-event-opts',1,'disabled',2,'mode',3,'range',4,'value',5],[],e,s,gg)
var t5D=_n('view')
_rz(z,t5D,'class',7,e,s,gg)
var e6D=_oz(z,8,e,s,gg)
_(t5D,e6D)
_(a4D,t5D)
_(r,a4D)
return r
}