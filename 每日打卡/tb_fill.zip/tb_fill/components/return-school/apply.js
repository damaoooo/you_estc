(global.webpackJsonp = global.webpackJsonp || []).push([ [ "components/return-school/apply" ], {
    259: function(e, t, n) {
        n.r(t);
        var s = n(260), o = n(262);
        for (var i in o) "default" !== i && function(e) {
            n.d(t, e, function() {
                return o[e];
            });
        }(i);
        n(264);
        var r = n(14), a = Object(r.default)(o.default, s.render, s.staticRenderFns, !1, null, "08c26ea0", null);
        a.options.__file = "src/components/return-school/apply.vue", t.default = a.exports;
    },
    260: function(e, t, n) {
        n.r(t);
        var s = n(261);
        n.d(t, "render", function() {
            return s.render;
        }), n.d(t, "staticRenderFns", function() {
            return s.staticRenderFns;
        });
    },
    261: function(e, t, n) {
        n.r(t), n.d(t, "render", function() {
            return s;
        }), n.d(t, "staticRenderFns", function() {
            return o;
        });
        var s = function() {
            var e = this, t = e.$createElement, n = (e._self._c, e.timeCheck());
            e.$mp.data = Object.assign({}, {
                $root: {
                    m0: n
                }
            });
        }, o = [];
        s._withStripped = !0;
    },
    262: function(e, t, n) {
        n.r(t);
        var s = n(263), o = n.n(s);
        for (var i in s) "default" !== i && function(e) {
            n.d(t, e, function() {
                return s[e];
            });
        }(i);
        t.default = o.a;
    },
    263: function(e, t, n) {
        (function(e) {
            function s(e) {
                return e && e.__esModule ? e : {
                    default: e
                };
            }
            function o(e, t, n, s, o, i, r) {
                try {
                    var a = e[i](r), c = a.value;
                } catch (e) {
                    return void n(e);
                }
                a.done ? t(c) : Promise.resolve(c).then(s, o);
            }
            function i(e) {
                return function() {
                    var t = this, n = arguments;
                    return new Promise(function(s, i) {
                        function r(e) {
                            o(c, s, i, r, a, "next", e);
                        }
                        function a(e) {
                            o(c, s, i, r, a, "throw", e);
                        }
                        var c = e.apply(t, n);
                        r(void 0);
                    });
                };
            }
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var r = s(n(16)), a = s(n(24)), c = new (n(168))({
                key: "OEABZ-I2G6D-G7N4N-HHBGB-CFZ35-VUBV5"
            }), u = [ [ "camera" ], [ "album" ], [ "camera", "album" ] ], d = [ [ "compressed" ], [ "original" ], [ "compressed", "original" ] ], l = {
                name: "apply",
                components: {},
                props: {
                    batchItem: {
                        type: Object,
                        default: function() {
                            return {};
                        }
                    }
                },
                data: function() {
                    return {
                        isBYS: !1,
                        isDelay: !1,
                        fileIds: [],
                        imageList: [],
                        imageLength: 1,
                        sourceTypeIndex: 2,
                        sizeTypeIndex: 2,
                        curentFile: null,
                        form: {
                            currentAddress: null,
                            isAgreen: !1,
                            needDefferReason: "",
                            returnReason: null
                        }
                    };
                },
                created: function() {
                    var t = JSON.parse(e.getStorageSync("userInfo"));
                    this.isBYS = 2016 == t.className.substring(0, 4);
                },
                mounted: function() {},
                methods: {
                    delayChange: function(e) {
                        this.fileIds = [], this.imageList = [], this.curentFile = null, "true" === e.detail.value || !0 === e.detail.value ? (this.imageLength = 3, 
                        this.isDelay = !0) : (this.imageLength = 1, this.isDelay = !1);
                    },
                    downloadFile: function() {
                        var t = this;
                        e.downloadFile({
                            url: "".concat(this.$fly.config.baseURL, "/api/wx/getCommitmentLetter"),
                            success: function(n) {
                                200 === n.statusCode && e.saveImageToPhotosAlbum({
                                    filePath: n.tempFilePath,
                                    success: function(e) {
                                        t.showToast("文件已保存至系统相册");
                                    }
                                });
                            }
                        });
                    },
                    submit: function() {
                        var e = this, t = null;
                        if (this.isDelay) {
                            if (!this.fileIds || !this.fileIds.length) return void this.showToast("请上传证明材料");
                            if (!this.form.needDefferReason) return void this.showToast("请输入申请理由");
                            t = {
                                needDeffer: this.isDelay,
                                needDefferPicture: this.fileIds.join(","),
                                needDefferReason: this.form.needDefferReason,
                                detailId: this.batchItem.id
                            };
                        } else {
                            if (!this.form.currentAddress) return void this.showToast("当前位置不能为空");
                            if (!this.batchItem.healthCardID) return void this.showToast("请填写健康申报卡");
                            if (!this.fileIds || !this.fileIds.length) return void this.showToast("请上传返校承诺书");
                            t = {
                                needDeffer: this.isDelay,
                                commitmentLetter: this.fileIds[0],
                                currentAddress: this.form.currentAddress,
                                detailId: this.batchItem.id
                            };
                        }
                        if (!this.isBYS) {
                            if (!this.form.returnReason) return void this.showToast("请填写申请理由");
                            t.returnReason = this.form.returnReason, t.needDeffer = null;
                        }
                        this.form.isAgreen ? this.$fly.post("./api/wx/commitReturnRegistrationApply", t).then(function(t) {
                            t.status ? e.$emit("callback", {
                                status: 1,
                                id: e.batchItem.id
                            }) : e.showToast(t.message);
                        }) : this.showToast("请勾选承诺信息");
                    },
                    goHealthCard: function() {
                        e.navigateTo({
                            url: "/pages/epidemic/returnSchool/healthCard?id=".concat(this.batchItem.id)
                        });
                    },
                    radioChange: function() {
                        this.form.isAgreen = !this.form.isAgreen;
                    },
                    showToast: function() {
                        var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "", n = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "none", s = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 1e3;
                        e.showToast({
                            title: t,
                            icon: n,
                            duration: s
                        });
                    },
                    timeCheck: function() {
                        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : this.batchItem.endTime, t = Date.now();
                        return (e = (0, a.default)(e).valueOf()) > t;
                    },
                    getLocation: function() {
                        var t = this;
                        e.getLocation({
                            type: "gcj02",
                            success: function(n) {
                                c.reverseGeocoder({
                                    location: {
                                        latitude: n.latitude,
                                        longitude: n.longitude
                                    },
                                    success: function(n) {
                                        e.showToast({
                                            title: "位置信息:" + n.result.address,
                                            icon: "none"
                                        }, 1e3), t.$set(t.form, "currentAddress", n.result.address), t.$set(t.form, "province", n.result.address_component.province), 
                                        t.$set(t.form, "city", n.result.address_component.city), t.$set(t.form, "county", n.result.address_component.district), 
                                        e.setStorageSync("location", {
                                            province: n.result.address_component.province,
                                            city: n.result.address_component.city,
                                            district: n.result.address_component.district,
                                            address: n.result.address
                                        }), "成都市" === n.result.address_component.city ? t.$set(t.form, "isLeaveChengdu", 0) : t.$set(t.form, "isLeaveChengdu", 1);
                                    },
                                    complete: function(n) {
                                        e.showToast({
                                            title: "位置信息:" + n.result.address,
                                            icon: "none"
                                        }, 1e3), console.log("complete", n), t.$set(t.form, "currentAddress", n.result.address), 
                                        t.$set(t.form, "province", n.result.address_component.province), t.$set(t.form, "city", n.result.address_component.city), 
                                        t.$set(t.form, "county", n.result.address_component.district), e.setStorageSync("location", {
                                            province: n.result.address_component.province,
                                            city: n.result.address_component.city,
                                            district: n.result.address_component.district,
                                            address: n.result.address
                                        }), "成都市" === n.result.address_component.city ? t.$set(t.form, "isLeaveChengdu", 0) : t.$set(t.form, "isLeaveChengdu", 1);
                                    },
                                    fail: function(t) {
                                        e.showToast({
                                            title: "获取位置信息失败！",
                                            icon: "none"
                                        }, 1e3);
                                    }
                                });
                            },
                            fail: function(t) {
                                e.showToast({
                                    title: "获取定位失败，请打开定位，重新进入！",
                                    icon: "none"
                                }, 1e3);
                            }
                        });
                    },
                    chooseImage: function() {
                        var t = i(r.default.mark(function t() {
                            var n = this;
                            return r.default.wrap(function(t) {
                                for (;;) switch (t.prev = t.next) {
                                  case 0:
                                    e.chooseImage({
                                        sourceType: u[this.sourceTypeIndex],
                                        sizeType: d[this.sizeTypeIndex],
                                        count: this.imageLength - this.imageList.length,
                                        success: function(t) {
                                            for (var s = t.tempFiles, o = [], i = 0; i < s.length; i++) s[i].size <= 1e6 ? o.push(t.tempFilePaths[i]) : e.showToast({
                                                title: "上传图片不能大于1M!",
                                                icon: "none",
                                                duration: 1e3
                                            });
                                            o.length && (n.curentFile = o, o.forEach(function(e) {
                                                n.uploadFile([ e ]);
                                            }));
                                        }
                                    });

                                  case 1:
                                  case "end":
                                    return t.stop();
                                }
                            }, t, this);
                        }));
                        return function() {
                            return t.apply(this, arguments);
                        };
                    }(),
                    previewImage: function(t) {
                        var n = t.target.dataset.src, s = [];
                        this.imageList.map(function(e) {
                            s.push(e.url);
                        }), e.previewImage({
                            current: n,
                            urls: this.imageList
                        });
                    },
                    deleteImage: function(e) {
                        var t = this, n = t.imageList;
                        n.splice(e, 1), t.imageList = n, this.fileIds.splice(e, 1);
                    },
                    uploadFile: function(t) {
                        var n = this;
                        e.uploadFile({
                            header: {
                                "Content-Type": "multipart/form-data"
                            },
                            url: "".concat(this.$fly.config.baseURL, "/api/common/wxUploadFile"),
                            filePath: t[0],
                            name: "file",
                            formData: {},
                            success: function(s) {
                                if (413 === s.statusCode) e.showToast({
                                    title: "图片过大，上传失败",
                                    icon: "none",
                                    duration: 1e3
                                }); else {
                                    var o = JSON.parse(s.data);
                                    o.status ? (n.imageList = n.imageList.concat(t), n.fileIds.push(o.data.id)) : e.showToast({
                                        title: "上传图片失败",
                                        icon: "none",
                                        duration: 1e3
                                    });
                                }
                            },
                            fail: function(t) {
                                e.showToast({
                                    title: "上传图片失败",
                                    icon: "none",
                                    duration: 1e3
                                });
                            },
                            complete: function(e) {}
                        }).onProgressUpdate(function(e) {});
                    }
                }
            };
            t.default = l;
        }).call(this, n(1).default);
    },
    264: function(e, t, n) {
        n.r(t);
        var s = n(265), o = n.n(s);
        for (var i in s) "default" !== i && function(e) {
            n.d(t, e, function() {
                return s[e];
            });
        }(i);
        t.default = o.a;
    },
    265: function(e, t, n) {}
} ]), (global.webpackJsonp = global.webpackJsonp || []).push([ "components/return-school/apply-create-component", {
    "components/return-school/apply-create-component": function(e, t, n) {
        n("1").createComponent(n(259));
    }
}, [ [ "components/return-school/apply-create-component" ] ] ]);