function(e,s,r,gg){
var z=gz$gwx_7()
var o8D=_n('view')
_rz(z,o8D,'class',0,e,s,gg)
var x9D=_n('view')
_rz(z,x9D,'class',1,e,s,gg)
var o0D=_mz(z,'icon',['class',2,'size',1,'type',2],[],e,s,gg)
_(x9D,o0D)
_(o8D,x9D)
var fAE=_n('view')
_rz(z,fAE,'class',5,e,s,gg)
var cEE=_n('view')
_rz(z,cEE,'class',6,e,s,gg)
var oFE=_oz(z,7,e,s,gg)
_(cEE,oFE)
_(fAE,cEE)
var lGE=_v()
_(fAE,lGE)
var aHE=function(eJE,tIE,bKE,gg){
var xME=_n('view')
_rz(z,xME,'class',12,eJE,tIE,gg)
var oNE=_oz(z,13,eJE,tIE,gg)
_(xME,oNE)
_(bKE,xME)
return bKE
}
lGE.wxXCkey=2
_2z(z,10,aHE,e,s,gg,lGE,'item','__i0__','*this')
var cBE=_v()
_(fAE,cBE)
if(_oz(z,14,e,s,gg)){cBE.wxVkey=1
var fOE=_mz(z,'sectio',['bind:__l',15,'class',1,'vueId',2,'vueSlots',3],[],e,s,gg)
var cPE=_v()
_(fOE,cPE)
var hQE=function(cSE,oRE,oTE,gg){
var aVE=_mz(z,'view',['class',23,'style',1],[],cSE,oRE,gg)
var tWE=_oz(z,25,cSE,oRE,gg)
_(aVE,tWE)
_(oTE,aVE)
return oTE
}
cPE.wxXCkey=2
_2z(z,21,hQE,e,s,gg,cPE,'item','__i1__','*this')
_(cBE,fOE)
}
var hCE=_v()
_(fAE,hCE)
if(_oz(z,26,e,s,gg)){hCE.wxVkey=1
var eXE=_mz(z,'button',['class',27,'disabled',1,'size',2,'type',3],[],e,s,gg)
var bYE=_oz(z,31,e,s,gg)
_(eXE,bYE)
_(hCE,eXE)
}
var oDE=_v()
_(fAE,oDE)
if(_oz(z,32,e,s,gg)){oDE.wxVkey=1
var oZE=_mz(z,'button',['bindtap',33,'class',1,'data-event-opts',2,'size',3,'type',4],[],e,s,gg)
var x1E=_oz(z,38,e,s,gg)
_(oZE,x1E)
_(oDE,oZE)
}
var o2E=_n('view')
_rz(z,o2E,'class',39,e,s,gg)
var f3E=_v()
_(o2E,f3E)
if(_oz(z,40,e,s,gg)){f3E.wxVkey=1
var c4E=_mz(z,'label',['bindtap',41,'class',1,'data-event-opts',2],[],e,s,gg)
var h5E=_oz(z,44,e,s,gg)
_(c4E,h5E)
_(f3E,c4E)
}
f3E.wxXCkey=1
_(fAE,o2E)
cBE.wxXCkey=1
hCE.wxXCkey=1
oDE.wxXCkey=1
_(o8D,fAE)
_(r,o8D)
return r
}