(global.webpackJsonp = global.webpackJsonp || []).push([ [ "components/return-school/apply-result" ], {
    266: function(t, n, e) {
        e.r(n);
        var i = e(267), s = e(269);
        for (var c in s) "default" !== c && function(t) {
            e.d(n, t, function() {
                return s[t];
            });
        }(c);
        e(271);
        var a = e(14), o = Object(a.default)(s.default, i.render, i.staticRenderFns, !1, null, "c70821ec", null);
        o.options.__file = "src/components/return-school/apply-result.vue", n.default = o.exports;
    },
    267: function(t, n, e) {
        e.r(n);
        var i = e(268);
        e.d(n, "render", function() {
            return i.render;
        }), e.d(n, "staticRenderFns", function() {
            return i.staticRenderFns;
        });
    },
    268: function(t, n, e) {
        e.r(n), e.d(n, "render", function() {
            return i;
        }), e.d(n, "staticRenderFns", function() {
            return s;
        });
        var i = function() {
            var t = this, n = t.$createElement;
            t._self._c;
        }, s = [];
        i._withStripped = !0;
    },
    269: function(t, n, e) {
        e.r(n);
        var i = e(270), s = e.n(i);
        for (var c in i) "default" !== c && function(t) {
            e.d(n, t, function() {
                return i[t];
            });
        }(c);
        n.default = s.a;
    },
    270: function(t, n, e) {
        (function(t) {
            Object.defineProperty(n, "__esModule", {
                value: !0
            }), n.default = void 0;
            var i = function(t) {
                return t && t.__esModule ? t : {
                    default: t
                };
            }(e(24)), s = {
                name: "apply-result",
                components: {},
                props: {
                    batchItem: {
                        type: Object,
                        default: function() {
                            return {};
                        }
                    }
                },
                data: function() {
                    return {
                        iconType: "success",
                        info: {},
                        btnTitle: "返校交通信息填写"
                    };
                },
                watch: {
                    batchItem: {
                        handler: function() {
                            this.init();
                        },
                        deep: !0
                    }
                },
                mounted: function() {
                    this.init();
                },
                methods: {
                    init: function() {
                        this.btnTitle = "返校交通信息填写", 1 === this.batchItem.status ? (this.iconType = "success", 
                        this.info = {
                            title: "提交成功",
                            tips: [ "等待辅导员确认申请", "感谢您的配合" ],
                            btnStatus: 0,
                            isBack: !1
                        }) : 2 === this.batchItem.status ? (this.iconType = "cancel", this.info = {
                            title: "批次过时",
                            tips: [ "请等待下一批次" ],
                            btnStatus: 0,
                            isBack: !0
                        }) : 3 === this.batchItem.status ? (this.iconType = "cancel", this.info = {
                            title: "审核过时",
                            tips: [ "请等待下一批次", '"来自系统意见"' ],
                            btnStatus: 0,
                            isBack: !0
                        }) : 4 === this.batchItem.status ? (this.iconType = "success", this.info = {
                            title: "同意返校",
                            tips: [ '"来自辅导员意见"' ],
                            warning: [ "若乘坐飞机，值机完成后，请及时到交通信息中更新座位号" ],
                            btnStatus: 2,
                            isBack: !1
                        }) : 5 === this.batchItem.status ? (this.iconType = "cancel", this.info = {
                            title: "延期返校",
                            tips: [ "延期返校至".concat(this.batchItem.delayTime), '"来自辅导员意见"' ],
                            btnStatus: 2,
                            isBack: !1
                        }) : 6 === this.batchItem.status ? (this.iconType = "cancel", this.info = {
                            title: "暂缓返校",
                            tips: [ "请等待下一批次", '"来自辅导员意见"' ],
                            btnStatus: 0,
                            isBack: !0
                        }) : 7 === this.batchItem.status ? (this.iconType = "success", this.info = {
                            title: "已注册",
                            tips: [ '"您已经报到注册成功"' ],
                            btnStatus: 2,
                            isBack: !1
                        }, this.btnTitle = "修改返校交通信息") : 8 === this.batchItem.status && (this.iconType = "success", 
                        this.info = {
                            title: "已登记",
                            tips: [ "返校交通信息已填写完成，若有变动，请及时更新" ],
                            warning: [ "若乘坐飞机，值机完成后，请及时到交通信息中更新座位号" ],
                            btnStatus: 2,
                            isBack: !1
                        }, this.btnTitle = "修改返校交通信息");
                    },
                    goBack: function() {
                        this.$emit("callback", {
                            id: null,
                            status: null
                        });
                    },
                    goApplyResult: function() {
                        t.navigateTo({
                            url: "/pages/epidemic/returnSchool/returnInfo?id=".concat(this.batchItem.id)
                        });
                    },
                    checkTime: function(t) {
                        var n = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : Date.now();
                        return (t = (0, i.default)(t).valueOf()) > n ? 1 : 2;
                    }
                }
            };
            n.default = s;
        }).call(this, e(1).default);
    },
    271: function(t, n, e) {
        e.r(n);
        var i = e(272), s = e.n(i);
        for (var c in i) "default" !== c && function(t) {
            e.d(n, t, function() {
                return i[t];
            });
        }(c);
        n.default = s.a;
    },
    272: function(t, n, e) {}
} ]), (global.webpackJsonp = global.webpackJsonp || []).push([ "components/return-school/apply-result-create-component", {
    "components/return-school/apply-result-create-component": function(t, n, e) {
        e("1").createComponent(e(266));
    }
}, [ [ "components/return-school/apply-result-create-component" ] ] ]);