(global.webpackJsonp = global.webpackJsonp || []).push([ [ "common/main" ], [ function(n, e, t) {
    (function(n) {
        function e(n) {
            return n && n.__esModule ? n : {
                default: n
            };
        }
        function o(n, e, t) {
            return e in n ? Object.defineProperty(n, e, {
                value: t,
                enumerable: !0,
                configurable: !0,
                writable: !0
            }) : n[e] = t, n;
        }
        t(4), t(5);
        var u = e(t(2)), a = e(t(9)), r = e(t(15)), f = e(t(20)), l = e(t(23));
        u.default.config.productionTip = !1, u.default.prototype.$store = r.default, u.default.prototype.$fly = f.default, 
        u.default.prototype.$backgroundAudioData = {
            playing: !1,
            playTime: 0,
            formatedPlayTime: "00:00:00"
        }, Object.keys(l.default).forEach(function(n) {
            u.default.filter(n, l.default[n]);
        }), u.default.component("page-head", function() {
            return t.e("components/page-head").then(t.bind(null, 247));
        }), u.default.component("page-foot", function() {
            return t.e("components/page-foot").then(t.bind(null, 252));
        }), a.default.mpType = "app", n(new u.default(function(n) {
            for (var e = 1; e < arguments.length; e++) {
                var t = null != arguments[e] ? arguments[e] : {}, u = Object.keys(t);
                "function" == typeof Object.getOwnPropertySymbols && (u = u.concat(Object.getOwnPropertySymbols(t).filter(function(n) {
                    return Object.getOwnPropertyDescriptor(t, n).enumerable;
                }))), u.forEach(function(e) {
                    o(n, e, t[e]);
                });
            }
            return n;
        }({
            store: r.default
        }, a.default))).$mount();
    }).call(this, t(1).createApp);
}, , , , , , , , , function(n, e, t) {
    t.r(e);
    var o = t(10);
    for (var u in o) "default" !== u && function(n) {
        t.d(e, n, function() {
            return o[n];
        });
    }(u);
    t(12);
    var a = t(14), r = Object(a.default)(o.default, void 0, void 0, !1, null, null, null);
    r.options.__file = "src/App.vue", e.default = r.exports;
}, function(n, e, t) {
    t.r(e);
    var o = t(11), u = t.n(o);
    for (var a in o) "default" !== a && function(n) {
        t.d(e, n, function() {
            return o[n];
        });
    }(a);
    e.default = u.a;
}, function(n, e, t) {
    Object.defineProperty(e, "__esModule", {
        value: !0
    }), e.default = void 0;
    var o = {
        onLaunch: function() {
            console.log("App Launch");
        },
        onShow: function() {},
        onHide: function() {
            console.log("App Hide");
        }
    };
    e.default = o;
}, function(n, e, t) {
    t.r(e);
    var o = t(13), u = t.n(o);
    for (var a in o) "default" !== a && function(n) {
        t.d(e, n, function() {
            return o[n];
        });
    }(a);
    e.default = u.a;
}, function(n, e, t) {} ], [ [ 0, "common/runtime", "common/vendor" ] ] ]);