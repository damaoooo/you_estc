(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/main/login/login" ], {
    154: function(n, e, t) {
        (function(n) {
            function e(n) {
                return n && n.__esModule ? n : {
                    default: n
                };
            }
            t(4), t(5);
            e(t(2));
            n(e(t(155)).default);
        }).call(this, t(1).createPage);
    },
    155: function(n, e, t) {
        t.r(e);
        var i = t(156), o = t(158);
        for (var a in o) "default" !== a && function(n) {
            t.d(e, n, function() {
                return o[n];
            });
        }(a);
        t(160);
        var u = t(14), r = Object(u.default)(o.default, i.render, i.staticRenderFns, !1, null, "1cc11ff1", null);
        r.options.__file = "src/pages/main/login/login.vue", e.default = r.exports;
    },
    156: function(n, e, t) {
        t.r(e);
        var i = t(157);
        t.d(e, "render", function() {
            return i.render;
        }), t.d(e, "staticRenderFns", function() {
            return i.staticRenderFns;
        });
    },
    157: function(n, e, t) {
        t.r(e), t.d(e, "render", function() {
            return i;
        }), t.d(e, "staticRenderFns", function() {
            return o;
        });
        var i = function() {
            var n = this, e = n.$createElement;
            n._self._c;
        }, o = [];
        i._withStripped = !0;
    },
    158: function(n, e, t) {
        t.r(e);
        var i = t(159), o = t.n(i);
        for (var a in i) "default" !== a && function(n) {
            t.d(e, n, function() {
                return i[n];
            });
        }(a);
        e.default = o.a;
    },
    159: function(n, e, t) {
        (function(n) {
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.default = void 0;
            var t = {
                name: "login",
                data: function() {
                    return {
                        userInfo: {
                            code: null,
                            sn: null,
                            idCard: null,
                            avatarurl: null,
                            nickname: null
                        },
                        isShow: !0
                    };
                },
                onLoad: function() {},
                onShow: function() {
                    var e = this;
                    n.removeStorageSync("location");
                    var t = n.getUpdateManager();
                    n.showLoading({
                        title: "检查更新...",
                        mask: !0
                    }), t.onCheckForUpdate(function(t) {
                        n.hideLoading(), t.hasUpdate ? n.showLoading({
                            title: "正在为您更新程序，请稍候...",
                            mask: !0
                        }) : e.wxLogin();
                    }), t.onUpdateReady(function(e) {
                        n.hideLoading(), t.applyUpdate();
                    }), t.onUpdateFailed(function(e) {
                        n.showToast({
                            title: "检查更新失败",
                            icon: "none",
                            duration: 2e3
                        });
                    });
                },
                methods: {
                    getUserInfo: function(e) {
                        e.detail.iv ? (this.userInfo.avatarurl = e.mp.detail.userInfo.avatarUrl, this.userInfo.nickname = e.mp.detail.userInfo.nickName, 
                        this.login(this.userInfo)) : n.showToast({
                            title: "你取消了授权，登录失败！",
                            icon: "none",
                            duration: 1e3
                        });
                    },
                    wxLogin: function() {
                        var e = this;
                        n.login({
                            success: function(t) {
                                e.userInfo.code = t.code, e.$fly.post("./api/epidemic/login/checkBind", e.userInfo).then(function(t) {
                                    t.status && (n.setStorageSync("sessionId", t.data.sessionId), !1 === t.data.bind ? e.isShow = !0 : !0 === t.data.bind && (n.setStorageSync("userInfo", JSON.stringify(t.data.user)), 
                                    e.isShow = !1, n.switchTab({
                                        url: "/pages/epidemic/everyDay/everyDay"
                                    })));
                                });
                            }
                        });
                    },
                    login: function(e) {
                        if (null === e.sn || "" === e.sn || null === e.idCard || "" === e.idCard) n.showToast({
                            title: "用户名或密码错误",
                            icon: "none",
                            duration: 1e3
                        }); else {
                            delete e.code;
                            var t = /([^\u0020-\u007E\u00A0-\u00BE\u2E80-\uA4CF\uF900-\uFAFF\uFE30-\uFE4F\uFF00-\uFFEF\u0080-\u009F\u2000-\u201f\u2026\u2022\u20ac\r\n])|(\s)/g;
                            e.nickname = e.nickname.replace(t, ""), this.$fly.post("./api/epidemic/login/bindUserInfo", e).then(function(e) {
                                e.status ? (n.setStorageSync("userInfo", JSON.stringify(e.data.user)), n.switchTab({
                                    url: "/pages/epidemic/everyDay/everyDay"
                                })) : n.showToast({
                                    title: e.message,
                                    icon: "none",
                                    duration: 1e3
                                });
                            });
                        }
                    }
                }
            };
            e.default = t;
        }).call(this, t(1).default);
    },
    160: function(n, e, t) {
        t.r(e);
        var i = t(161), o = t.n(i);
        for (var a in i) "default" !== a && function(n) {
            t.d(e, n, function() {
                return i[n];
            });
        }(a);
        e.default = o.a;
    },
    161: function(n, e, t) {}
}, [ [ 154, "common/runtime", "common/vendor" ] ] ]);