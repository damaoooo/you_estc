function(e,s,r,gg){
var z=gz$gwx_19()
var hCZ=_n('view')
_rz(z,hCZ,'class',0,e,s,gg)
var oDZ=_n('view')
_rz(z,oDZ,'class',1,e,s,gg)
var cEZ=_oz(z,2,e,s,gg)
_(oDZ,cEZ)
_(hCZ,oDZ)
var oFZ=_mz(z,'button',['ariaDisabled',3,'bindtap',1,'class',2,'data-event-opts',3,'role',4],[],e,s,gg)
var lGZ=_oz(z,8,e,s,gg)
_(oFZ,lGZ)
_(hCZ,oFZ)
_(r,hCZ)
return r
}