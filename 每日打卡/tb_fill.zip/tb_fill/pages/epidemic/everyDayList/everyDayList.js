(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/epidemic/everyDayList/everyDayList" ], {
    223: function(t, e, n) {
        (function(t) {
            function e(t) {
                return t && t.__esModule ? t : {
                    default: t
                };
            }
            n(4), n(5);
            e(n(2));
            t(e(n(224)).default);
        }).call(this, n(1).createPage);
    },
    224: function(t, e, n) {
        n.r(e);
        var r = n(225), i = n(227);
        for (var a in i) "default" !== a && function(t) {
            n.d(e, t, function() {
                return i[t];
            });
        }(a);
        n(229);
        var u = n(14), o = Object(u.default)(i.default, r.render, r.staticRenderFns, !1, null, "42d8a20c", null);
        o.options.__file = "src/pages/epidemic/everyDayList/everyDayList.vue", e.default = o.exports;
    },
    225: function(t, e, n) {
        n.r(e);
        var r = n(226);
        n.d(e, "render", function() {
            return r.render;
        }), n.d(e, "staticRenderFns", function() {
            return r.staticRenderFns;
        });
    },
    226: function(t, e, n) {
        n.r(e), n.d(e, "render", function() {
            return r;
        }), n.d(e, "staticRenderFns", function() {
            return i;
        });
        var r = function() {
            var t = this, e = t.$createElement, n = (t._self._c, t.__map(t.list, function(e, n) {
                var r = t.formatDate(e.registerTime);
                return {
                    $orig: t.__get_orig(e),
                    m0: r
                };
            }));
            t.$mp.data = Object.assign({}, {
                $root: {
                    l0: n
                }
            });
        }, i = [];
        r._withStripped = !0;
    },
    227: function(t, e, n) {
        n.r(e);
        var r = n(228), i = n.n(r);
        for (var a in r) "default" !== a && function(t) {
            n.d(e, t, function() {
                return r[t];
            });
        }(a);
        e.default = i.a;
    },
    228: function(t, e, n) {
        (function(t) {
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.default = void 0;
            var r = function(t) {
                return t && t.__esModule ? t : {
                    default: t
                };
            }(n(24)), i = {
                name: "everyDayList",
                data: function() {
                    return {
                        list: []
                    };
                },
                onShow: function() {
                    this.getList();
                },
                methods: {
                    formatDate: function(t) {
                        return t ? (0, r.default)(t).format("YYYY.MM.DD") : "";
                    },
                    getList: function() {
                        var t = this;
                        this.$fly.post("./listPage").then(function(e) {
                            e.status && (t.list = e.data);
                        });
                    },
                    goDetail: function(e) {
                        t.navigateTo({
                            url: "/pages/epidemic/everyDayDetail/everyDayDetail?id=" + e
                        });
                    }
                }
            };
            e.default = i;
        }).call(this, n(1).default);
    },
    229: function(t, e, n) {
        n.r(e);
        var r = n(230), i = n.n(r);
        for (var a in r) "default" !== a && function(t) {
            n.d(e, t, function() {
                return r[t];
            });
        }(a);
        e.default = i.a;
    },
    230: function(t, e, n) {}
}, [ [ 223, "common/runtime", "common/vendor" ] ] ]);