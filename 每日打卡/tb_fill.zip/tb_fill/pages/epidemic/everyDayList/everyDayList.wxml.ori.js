function(e,s,r,gg){
var z=gz$gwx_12()
var tEP=_n('view')
_rz(z,tEP,'class',0,e,s,gg)
var bGP=_v()
_(tEP,bGP)
var oHP=function(oJP,xIP,fKP,gg){
var hMP=_mz(z,'view',['bindtap',5,'class',1,'data-event-opts',2],[],oJP,xIP,gg)
var oNP=_n('view')
_rz(z,oNP,'class',8,oJP,xIP,gg)
var cOP=_v()
_(oNP,cOP)
if(_oz(z,9,oJP,xIP,gg)){cOP.wxVkey=1
var oPP=_n('view')
_rz(z,oPP,'class',10,oJP,xIP,gg)
_(cOP,oPP)
}
else{cOP.wxVkey=2
var lQP=_n('view')
_rz(z,lQP,'class',11,oJP,xIP,gg)
_(cOP,lQP)
}
var aRP=_mz(z,'image',['class',12,'mode',1,'src',2],[],oJP,xIP,gg)
_(oNP,aRP)
var tSP=_n('label')
_rz(z,tSP,'class',15,oJP,xIP,gg)
var eTP=_oz(z,16,oJP,xIP,gg)
_(tSP,eTP)
_(oNP,tSP)
cOP.wxXCkey=1
_(hMP,oNP)
var bUP=_n('view')
_rz(z,bUP,'class',17,oJP,xIP,gg)
var oVP=_n('view')
_rz(z,oVP,'class',18,oJP,xIP,gg)
var xWP=_v()
_(oVP,xWP)
if(_oz(z,19,oJP,xIP,gg)){xWP.wxVkey=1
var oXP=_n('view')
_rz(z,oXP,'class',20,oJP,xIP,gg)
var fYP=_oz(z,21,oJP,xIP,gg)
_(oXP,fYP)
_(xWP,oXP)
}
else{xWP.wxVkey=2
var cZP=_n('view')
_rz(z,cZP,'class',22,oJP,xIP,gg)
var h1P=_oz(z,23,oJP,xIP,gg)
_(cZP,h1P)
_(xWP,cZP)
}
var o2P=_n('view')
_rz(z,o2P,'class',24,oJP,xIP,gg)
var c3P=_mz(z,'image',['class',25,'mode',1,'src',2],[],oJP,xIP,gg)
_(o2P,c3P)
var o4P=_n('label')
_rz(z,o4P,'class',28,oJP,xIP,gg)
var l5P=_oz(z,29,oJP,xIP,gg)
_(o4P,l5P)
_(o2P,o4P)
_(oVP,o2P)
xWP.wxXCkey=1
_(bUP,oVP)
var a6P=_n('label')
_rz(z,a6P,'class',30,oJP,xIP,gg)
_(bUP,a6P)
_(hMP,bUP)
_(fKP,hMP)
return fKP
}
bGP.wxXCkey=2
_2z(z,3,oHP,e,s,gg,bGP,'item','__i0__','id')
var eFP=_v()
_(tEP,eFP)
if(_oz(z,31,e,s,gg)){eFP.wxVkey=1
var t7P=_n('view')
_rz(z,t7P,'class',32,e,s,gg)
var e8P=_oz(z,33,e,s,gg)
_(t7P,e8P)
_(eFP,t7P)
}
eFP.wxXCkey=1
_(r,tEP)
return r
}