(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/epidemic/everyDay/everyDay" ], {
    197: function(e, t, n) {
        (function(e) {
            function t(e) {
                return e && e.__esModule ? e : {
                    default: e
                };
            }
            n(4), n(5);
            t(n(2));
            e(t(n(198)).default);
        }).call(this, n(1).createPage);
    },
    198: function(e, t, n) {
        n.r(t);
        var o = n(199), s = n(201);
        for (var r in s) "default" !== r && function(e) {
            n.d(t, e, function() {
                return s[e];
            });
        }(r);
        n(203);
        var i = n(14), a = Object(i.default)(s.default, o.render, o.staticRenderFns, !1, null, "32690d68", null);
        a.options.__file = "src/pages/epidemic/everyDay/everyDay.vue", t.default = a.exports;
    },
    199: function(e, t, n) {
        n.r(t);
        var o = n(200);
        n.d(t, "render", function() {
            return o.render;
        }), n.d(t, "staticRenderFns", function() {
            return o.staticRenderFns;
        });
    },
    200: function(e, t, n) {
        n.r(t), n.d(t, "render", function() {
            return o;
        }), n.d(t, "staticRenderFns", function() {
            return s;
        });
        var o = function() {
            var e = this, t = e.$createElement, n = (e._self._c, e.form.healthInfoList.includes("发热")), o = e.form.healthInfoList.includes("呼吸道症状"), s = e.form.healthInfoList.includes("乏力"), r = e.form.healthInfoList.includes("畏寒"), i = e.form.healthInfoList.includes("腹泻"), a = e.form.healthInfoList.includes("结膜充血");
            e.$mp.data = Object.assign({}, {
                $root: {
                    g0: n,
                    g1: o,
                    g2: s,
                    g3: r,
                    g4: i,
                    g5: a
                }
            });
        }, s = [];
        o._withStripped = !0;
    },
    201: function(e, t, n) {
        n.r(t);
        var o = n(202), s = n.n(o);
        for (var r in o) "default" !== r && function(e) {
            n.d(t, e, function() {
                return o[e];
            });
        }(r);
        t.default = s.a;
    },
    202: function(e, t, n) {
        (function(e) {
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var o = function(e) {
                return e && e.__esModule ? e : {
                    default: e
                };
            }(n(24)), s = new (n(168))({
                key: "OEABZ-I2G6D-G7N4N-HHBGB-CFZ35-VUBV5"
            }), r = {
                name: "everyDay",
                components: {
                    myTab: function() {
                        return n.e("components/my-tab/index").then(n.bind(null, 290));
                    },
                    everydayHealth: function() {
                        return n.e("components/everyday/everydayHealth").then(n.bind(null, 297));
                    }
                },
                data: function() {
                    return {
                        status: 0,
                        templetRange: [ "36°C以下", "36°C~36.5°C", "36.5°C~36.9°C", "36.9°C~37.3°C", "37.3°C~38°C", "38°C~38.5°C", "38.5°C~39°C", "39°C~40°C", "40°C以上" ],
                        dateNow: (0, o.default)().format("YYYY年MM月DD日"),
                        location: "",
                        form: {
                            currentAddress: "",
                            remark: "",
                            healthInfo: "正常",
                            isContactWuhan: 0,
                            isFever: 0,
                            isInSchool: 0,
                            isLeaveChengdu: "",
                            isSymptom: 0,
                            temperature: "",
                            province: "",
                            city: "",
                            county: "",
                            healthInfoList: []
                        }
                    };
                },
                onShareAppMessage: function(e) {
                    return {
                        title: "每日填报",
                        path: "/pages/epidemic/back/back"
                    };
                },
                onShow: function() {
                    this.checkState();
                },
                methods: {
                    everydayHealthSuccess: function() {
                        this.status = 3;
                    },
                    healthInfoChange: function(e) {
                        console.log(e), this.form.healthInfoList = e.detail.value;
                    },
                    checkState: function() {
                        var t = this;
                        this.$fly.get("./checkRegisterNew").then(function(n) {
                            if (n.status && (console.log(n), 0 == n.data.schoolStatus ? 0 === n.data.appliedTimes ? t.status = 0 : t.status = 1 : 0 === n.data.appliedTimes ? t.status = 2 : t.status = 3, 
                            0 == t.status)) {
                                var o = e.getStorageSync("location");
                                if (o) return t.$set(t.form, "currentAddress", o.address), t.$set(t.form, "province", o.province), 
                                t.$set(t.form, "city", o.city), void t.$set(t.form, "county", o.district);
                                t.getLocation();
                            }
                        });
                    },
                    submit: function() {
                        var t = this;
                        if (this.form.currentAddress) if (this.form.temperature) if ("正常" !== this.form.healthInfo || "36°C~36.5°C" === this.form.temperature || "36.5°C~36.9°C" === this.form.temperature) if ("异常" !== this.form.healthInfo || this.form.healthInfoList && 0 !== this.form.healthInfoList.length) {
                            var n = JSON.parse(JSON.stringify(this.form));
                            "异常" === n.healthInfo && (n.healthInfo = n.healthInfoList.join(",")), delete n.healthInfoList, 
                            this.$fly.post("./monitorRegister", n).then(function(n) {
                                n.status ? (e.showToast({
                                    title: "提交成功",
                                    icon: {
                                        none: !0
                                    },
                                    duration: 1e3
                                }), t.status = 1) : e.showToast({
                                    title: n.message,
                                    icon: {
                                        none: !0
                                    },
                                    duration: 1e3
                                });
                            });
                        } else e.showToast({
                            title: "请选择健康异常情况描述",
                            icon: "none",
                            duration: 2e3
                        }); else e.showToast({
                            title: "您的健康状况【正常】时，当前体温范围应为：36℃~36.5℃、36.5℃~36.9℃",
                            icon: "none",
                            duration: 2e3
                        }); else e.showToast({
                            title: "请选择当前体温",
                            icon: "none",
                            duration: 1e3
                        }); else e.showToast({
                            title: "请重新获取位置信息",
                            icon: "none",
                            duration: 1e3
                        });
                    },
                    radioChange: function(e, t) {
                        this.form[t] = e.detail.value;
                    },
                    temperatureChange: function(e) {
                        console.log(e), this.form.temperature = this.templetRange[e.detail.value];
                    },
                    getLocation: function() {
                        var t = this;
                        e.getLocation({
                            type: "gcj02",
                            success: function(n) {
                                s.reverseGeocoder({
                                    location: {
                                        latitude: n.latitude,
                                        longitude: n.longitude
                                    },
                                    success: function(n) {
                                        console.log("mapSuccess", n), 0 == n.status ? (e.showToast({
                                            title: "位置信息:" + n.result.address,
                                            icon: "none"
                                        }, 1e3), t.$set(t.form, "currentAddress", n.result.address), t.$set(t.form, "province", n.result.address_component.province), 
                                        t.$set(t.form, "city", n.result.address_component.city), t.$set(t.form, "county", n.result.address_component.district), 
                                        e.setStorageSync("location", {
                                            province: n.result.address_component.province,
                                            city: n.result.address_component.city,
                                            district: n.result.address_component.district,
                                            address: n.result.address
                                        }), "成都市" === n.result.address_component.city ? t.$set(t.form, "isLeaveChengdu", 0) : t.$set(t.form, "isLeaveChengdu", 1)) : e.showToast({
                                            title: n.message,
                                            icon: "none"
                                        }, 1e3);
                                    },
                                    complete: function(n) {
                                        0 == n.status ? (e.showToast({
                                            title: "位置信息:" + n.result.address,
                                            icon: "none"
                                        }, 1e3), console.log("complete", n), t.$set(t.form, "currentAddress", n.result.address), 
                                        t.$set(t.form, "province", n.result.address_component.province), t.$set(t.form, "city", n.result.address_component.city), 
                                        t.$set(t.form, "county", n.result.address_component.district), e.setStorageSync("location", {
                                            province: n.result.address_component.province,
                                            city: n.result.address_component.city,
                                            district: n.result.address_component.district,
                                            address: n.result.address
                                        }), "成都市" === n.result.address_component.city ? t.$set(t.form, "isLeaveChengdu", 0) : t.$set(t.form, "isLeaveChengdu", 1)) : e.showToast({
                                            title: n.message,
                                            icon: "none"
                                        }, 1e3);
                                    },
                                    fail: function(t) {
                                        e.showToast({
                                            title: "获取位置信息失败！",
                                            icon: "none"
                                        }, 1e3), console.log("mapFail11", t);
                                    }
                                });
                            },
                            fail: function(t) {
                                console.log("localFail", t), e.showToast({
                                    title: "获取定位失败，请打开定位，重新进入！",
                                    icon: "none"
                                }, 1e3);
                            }
                        });
                    }
                }
            };
            t.default = r;
        }).call(this, n(1).default);
    },
    203: function(e, t, n) {
        n.r(t);
        var o = n(204), s = n.n(o);
        for (var r in o) "default" !== r && function(e) {
            n.d(t, e, function() {
                return o[e];
            });
        }(r);
        t.default = s.a;
    },
    204: function(e, t, n) {}
}, [ [ 197, "common/runtime", "common/vendor" ] ] ]);