(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/epidemic/returnSchool/returnInfo" ], {
    179: function(t, e, n) {
        (function(t) {
            function e(t) {
                return t && t.__esModule ? t : {
                    default: t
                };
            }
            n(4), n(5);
            e(n(2));
            t(e(n(180)).default);
        }).call(this, n(1).createPage);
    },
    180: function(t, e, n) {
        n.r(e);
        var i = n(181), a = n(183);
        for (var r in a) "default" !== r && function(t) {
            n.d(e, t, function() {
                return a[t];
            });
        }(r);
        n(185), n(187);
        var o = n(14), s = Object(o.default)(a.default, i.render, i.staticRenderFns, !1, null, "ec7fb334", null);
        s.options.__file = "src/pages/epidemic/returnSchool/returnInfo.vue", e.default = s.exports;
    },
    181: function(t, e, n) {
        n.r(e);
        var i = n(182);
        n.d(e, "render", function() {
            return i.render;
        }), n.d(e, "staticRenderFns", function() {
            return i.staticRenderFns;
        });
    },
    182: function(t, e, n) {
        n.r(e), n.d(e, "render", function() {
            return i;
        }), n.d(e, "staticRenderFns", function() {
            return a;
        });
        var i = function() {
            var t = this, e = t.$createElement;
            t._self._c;
        }, a = [];
        i._withStripped = !0;
    },
    183: function(t, e, n) {
        n.r(e);
        var i = n(184), a = n.n(i);
        for (var r in i) "default" !== r && function(t) {
            n.d(e, t, function() {
                return i[t];
            });
        }(r);
        e.default = a.a;
    },
    184: function(t, e, n) {
        (function(t) {
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.default = void 0;
            var i = function(t) {
                return t && t.__esModule ? t : {
                    default: t
                };
            }(n(24)), a = {
                name: "back",
                components: {
                    ruiDatePicker: function() {
                        return Promise.all([ n.e("common/vendor"), n.e("components/rattenking-dtpicker/rattenking-dtpicker") ]).then(n.bind(null, 273));
                    },
                    cityPicker: function() {
                        return Promise.all([ n.e("common/vendor"), n.e("components/mpvue-citypicker/mpvueCityPicker") ]).then(n.bind(null, 280));
                    },
                    myTab: function() {
                        return n.e("components/my-tab/index").then(n.bind(null, 290));
                    }
                },
                data: function() {
                    return {
                        updateTime: "无",
                        pickerValueDefault: [ 0, 0, 0 ],
                        area: "",
                        detail: "",
                        travelRange: [ "汽车（自驾）", "汽车（长途大巴）", "汽车（出租车）", "地铁", "火车", "动车/高铁", "飞机", "轮船", "其他" ],
                        pickAddressOptions: [ "双流机场T1航站楼", "双流机场T2航站楼", "火车东站", "火车北站" ],
                        form: {
                            detailId: null,
                            departurePlace: "",
                            estimatedTime: "",
                            isNeedPick: null,
                            pickAddress: null,
                            travels: [ {
                                id: null,
                                isValid: !0,
                                detailId: null,
                                arrivalCity: "",
                                endTime: "",
                                departureCity: "",
                                startTime: "",
                                trafficInfo: "",
                                trafficType: null
                            } ]
                        },
                        btnStatus: !0
                    };
                },
                onLoad: function(t) {
                    this.form.detailId = t.id;
                },
                onShow: function() {
                    this.getDetail();
                },
                methods: {
                    formatDateF: function(t) {
                        return t ? (0, i.default)(t).format("YYYY-MM-DD HH:mm") : "";
                    },
                    checkForm: function() {
                        if (!this.area) return this.showToast("请选择出发地", 2e3), !1;
                        if (!this.form.estimatedTime) return this.showToast("请填写预计到校时间", 2e3), !1;
                        for (var t = [ {
                            key: "trafficType",
                            msg: "交通工具"
                        }, {
                            key: "trafficInfo",
                            msg: "交通信息"
                        }, {
                            key: "departureCity",
                            msg: "行程出发地"
                        }, {
                            key: "arrivalCity",
                            msg: "行程目的地"
                        }, {
                            key: "startTime",
                            msg: "开始时间"
                        }, {
                            key: "endTime",
                            msg: "结束时间"
                        } ], e = 0; e < this.form.travels.length; e++) {
                            for (var n = this.form.travels[e], a = 0; a < t.length; a++) if (!n[t[a].key]) return this.showToast("请填写完整返第 ".concat(e + 1, " 个交通方式【").concat(t[a].msg, "字段】"), 2e3), 
                            !1;
                            if ((0, i.default)(n.startTime).valueOf() >= (0, i.default)(n.endTime).valueOf()) return this.showToast("第 ".concat(e + 1, " 个交通方式的 开始时间 应晚于 结束时间"), 2e3), 
                            !1;
                            if ((0, i.default)(n.endTime).valueOf() > (0, i.default)(this.form.estimatedTime).valueOf()) return this.showToast("第 ".concat(e + 1, " 个交通方式的 结束时间 不能晚于 预计到校时间"), 2e3), 
                            !1;
                        }
                        return !0;
                    },
                    submit: function() {
                        var t = this;
                        if (!this.checkForm()) return !1;
                        if (!this.btnStatus) return !1;
                        this.btnStatus = !1;
                        var e = this;
                        setTimeout(function() {
                            e.btnStatus = !0;
                        }, 2e3);
                        var n = JSON.parse(JSON.stringify(this.form));
                        !!n.detailId || delete n.detailId, this.area && (n.departurePlace = this.area.split("-").join("")), 
                        16 === n.estimatedTime.length && (n.estimatedTime += ":00"), n.travels.map(function(t) {
                            16 === t.startTime.length && (t.startTime += ":00"), 16 === t.endTime.length && (t.endTime += ":00");
                        }), this.$fly.post("./api/wx/commitTravelInfo", n).then(function(e) {
                            e.status ? (t.showToast("提交成功"), setTimeout(function() {
                                t.goBack();
                            }, 1e3)) : t.showToast(e.message || "提交失败");
                        });
                    },
                    getDetail: function() {
                        var t = this;
                        this.$fly.post("./api/wx/getTravelInfo", {
                            detailId: this.form.detailId
                        }).then(function(e) {
                            e.status ? (e.data = e.data || {}, t.form = Object.assign(t.form, e.data), t.updateTime = e.data.updateTime || "无", 
                            e.data.departurePlace && (t.area = "".concat(e.data.province, "-").concat(e.data.city, "-").concat(e.data.county)), 
                            0 === t.form.travels.length && t.vehicleAdd()) : t.showToast(e.message || "获取数据失败");
                        });
                    },
                    goBack: function() {
                        t.switchTab({
                            url: "/pages/epidemic/returnSchool/returnSchool"
                        });
                    },
                    bindRegionChange: function(t) {
                        this.area = t.label;
                    },
                    travelsRegionChange: function(t, e, n) {
                        this.form.travels[e][n] = t.label;
                    },
                    bindReachTime: function(t) {
                        this.form.estimatedTime = t;
                    },
                    vehicleChange: function(t, e) {
                        this.form.travels[e].trafficType = this.travelRange[t.detail.value];
                    },
                    bindVehicleStartTime: function(t, e) {
                        this.form.travels[e].startTime = t;
                    },
                    bindVehicleEndTime: function(t, e) {
                        this.form.travels[e].endTime = t;
                    },
                    vehicleAdd: function() {
                        this.form.travels.push({
                            id: null,
                            isValid: !0,
                            detailId: this.form.detailId,
                            arrivalCity: "",
                            endTime: "",
                            departureCity: "",
                            startTime: "",
                            trafficInfo: "",
                            trafficType: null
                        });
                    },
                    vehicleDelete: function(t) {
                        this.form.travels.splice(t, 1);
                    },
                    pickChange: function(t, e) {
                        this.form[e] = "true" === t.detail.value, this.form[e] || (this.form.pickAddress = null);
                    },
                    pickAdderssChange: function(t) {
                        this.form.pickAddress = this.pickAddressOptions[t.detail.value];
                    },
                    showToast: function() {
                        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "", n = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 1e3, i = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : "none";
                        t.showToast({
                            title: e,
                            icon: i,
                            duration: n,
                            mask: !0
                        });
                    }
                }
            };
            e.default = a;
        }).call(this, n(1).default);
    },
    185: function(t, e, n) {
        n.r(e);
        var i = n(186), a = n.n(i);
        for (var r in i) "default" !== r && function(t) {
            n.d(e, t, function() {
                return i[t];
            });
        }(r);
        e.default = a.a;
    },
    186: function(t, e, n) {},
    187: function(t, e, n) {
        n.r(e);
        var i = n(188), a = n.n(i);
        for (var r in i) "default" !== r && function(t) {
            n.d(e, t, function() {
                return i[t];
            });
        }(r);
        e.default = a.a;
    },
    188: function(t, e, n) {}
}, [ [ 179, "common/runtime", "common/vendor" ] ] ]);