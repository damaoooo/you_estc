(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/epidemic/returnSchool/healthCard" ], {
    189: function(t, e, n) {
        (function(t) {
            function e(t) {
                return t && t.__esModule ? t : {
                    default: t
                };
            }
            n(4), n(5);
            e(n(2));
            t(e(n(190)).default);
        }).call(this, n(1).createPage);
    },
    190: function(t, e, n) {
        n.r(e);
        var i = n(191), a = n(193);
        for (var o in a) "default" !== o && function(t) {
            n.d(e, t, function() {
                return a[t];
            });
        }(o);
        n(195);
        var s = n(14), r = Object(s.default)(a.default, i.render, i.staticRenderFns, !1, null, "4cbc14f4", null);
        r.options.__file = "src/pages/epidemic/returnSchool/healthCard.vue", e.default = r.exports;
    },
    191: function(t, e, n) {
        n.r(e);
        var i = n(192);
        n.d(e, "render", function() {
            return i.render;
        }), n.d(e, "staticRenderFns", function() {
            return i.staticRenderFns;
        });
    },
    192: function(t, e, n) {
        n.r(e), n.d(e, "render", function() {
            return i;
        }), n.d(e, "staticRenderFns", function() {
            return a;
        });
        var i = function() {
            var t = this, e = t.$createElement;
            t._self._c;
        }, a = [];
        i._withStripped = !0;
    },
    193: function(t, e, n) {
        n.r(e);
        var i = n(194), a = n.n(i);
        for (var o in i) "default" !== o && function(t) {
            n.d(e, t, function() {
                return i[t];
            });
        }(o);
        e.default = a.a;
    },
    194: function(t, e, n) {
        (function(t) {
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.default = void 0;
            var i = {
                name: "healthCard",
                components: {
                    cityPicker: function() {
                        return Promise.all([ n.e("common/vendor"), n.e("components/mpvue-citypicker/mpvueCityPicker") ]).then(n.bind(null, 280));
                    },
                    ruiDatePicker: function() {
                        return Promise.all([ n.e("common/vendor"), n.e("components/rattenking-dtpicker/rattenking-dtpicker") ]).then(n.bind(null, 273));
                    }
                },
                data: function() {
                    return {
                        pickerValueDefault: [ 0, 0, 0 ],
                        ageRange: [],
                        question_1_options: [ {
                            value: "1",
                            name: "发热（≥37.3℃）",
                            key: "isHot"
                        }, {
                            value: "2",
                            name: "咳嗽",
                            key: "isCough"
                        }, {
                            value: "3",
                            name: "嗓子痛（咽痛）",
                            key: "isPain"
                        }, {
                            value: "4",
                            name: "胸闷",
                            key: "isChestTight"
                        }, {
                            value: "5",
                            name: "呼吸困难",
                            key: "isBreathDiff"
                        }, {
                            value: "6",
                            name: "其他症状",
                            key: "isOthers"
                        }, {
                            value: "0",
                            name: "无以上症状",
                            key: "health"
                        } ],
                        readyOnly: !1,
                        form: {
                            id: null,
                            name: null,
                            sn: null,
                            age: null,
                            createTime: "",
                            gender: "女",
                            telephone: null,
                            situation: {
                                isBreathDiff: !1,
                                isChestTight: !1,
                                isCough: !1,
                                isHot: !1,
                                isOthers: !1,
                                isPain: !1,
                                otherDescription: "",
                                status: 0
                            },
                            symptoms: [],
                            other_symptoms: null,
                            areaContact: {
                                isContact: !1,
                                date: null
                            },
                            areaRetention: {
                                city: "",
                                province: "",
                                date: "",
                                isRetention: !1
                            },
                            infectedContact: {
                                date: null,
                                isContact: !1
                            }
                        },
                        btnStatus: !0
                    };
                },
                onLoad: function(t) {
                    this.readyOnly = t.readyOnly;
                },
                onShow: function() {
                    this.init(), this.getDetail();
                },
                methods: {
                    init: function() {
                        for (var e = 15; e < 60; e++) this.ageRange.push(e);
                        var n = JSON.parse(t.getStorageSync("userInfo"));
                        this.form.name = n.name, this.form.sn = n.sn;
                    },
                    submit: function() {
                        var e = this;
                        if (!this.checkFrom()) return !1;
                        if (!this.btnStatus) return !1;
                        this.btnStatus = !1;
                        var n = this;
                        setTimeout(function() {
                            n.btnStatus = !0;
                        }, 2e3);
                        var i = JSON.parse(JSON.stringify(this.form));
                        this.question_1_options.map(function(t) {
                            "health" !== t.key && (i.situation[t.key] = t.checked);
                        }), i.symptoms.includes("0") ? i.situation.status = 0 : i.situation.status = 1, 
                        i.symptoms.includes("6") || (i.situation.otherDescription = ""), i.areaRetention.isRetention || (i.areaRetention.province = "", 
                        i.areaRetention.city = "", i.areaRetention.date = ""), i.infectedContact.isContact || (i.infectedContact.date = ""), 
                        i.areaContact.isContact || (i.areaContact.date = ""), this.$fly.post("./api/wx/commitHealthApplication", i).then(function(n) {
                            n.status ? (t.showToast({
                                title: "提交成功",
                                icon: {
                                    none: !0
                                },
                                duration: 1e3,
                                mask: !0
                            }), setTimeout(function() {
                                t.navigateBack();
                            }, 1e3)) : e.showToast(n.message);
                        });
                    },
                    checkFrom: function() {
                        var t = JSON.parse(JSON.stringify(this.form)), e = "", n = new RegExp(/^((13[0-9])|(14[5,7])|(15[0-3,5-9])|(17[0,3,5-8])|(18[0-9])|166|198|199|(147))\d{8}$/);
                        if (t.age ? t.telephone ? n.test(t.telephone) || (e = "联系电话格式不正确") : e = "请填写联系电话" : e = "请选择年龄", 
                        e) return this.showToast(e), !1;
                        if (0 === t.symptoms.length ? e = "请选择您近14天的健康状况" : t.symptoms.length > 1 && t.symptoms.includes("0") ? e = "“无以上症状”不能与其他选项同时选中" : t.symptoms.includes("6") && !t.situation.otherDescription && (e = "请填写其他症状"), 
                        e) return this.showToast(e), !1;
                        if (t.areaRetention.isRetention) {
                            if (!t.areaRetention.province && !t.areaRetention.city) return this.showToast("请选择涉及疫情地"), 
                            !1;
                            if (!t.areaRetention.date) return this.showToast("请选择蓉时间"), !1;
                        }
                        return t.infectedContact.isContact && !t.infectedContact.date ? (this.showToast("请选择最后接触时间"), 
                        !1) : !(t.areaContact.isContact && !t.areaContact.date) || (this.showToast("请选择最后往来时间"), 
                        !1);
                    },
                    getDetail: function() {
                        var t = this;
                        this.form.symptoms = [], this.$fly.post("./api/wx/getHealthApplication", {}).then(function(e) {
                            e.status ? e.data && (t.form = Object.assign(t.form, e.data), 0 === t.form.situation.status ? (t.form.symptoms.push(0), 
                            t.question_1_options[6].checked = !0) : t.question_1_options.map(function(e) {
                                t.form.situation[e.key] && (e.checked = !0, t.form.symptoms.push(e.value));
                            })) : t.showToast(e.message);
                        });
                    },
                    genderChange: function(t, e, n) {
                        e && n ? this.form[e][n] = "true" === t.detail.value : e && !n && (this.form[e] = t.detail.value);
                    },
                    ageChange: function(t) {
                        this.form.age = this.ageRange[t.detail.value] + "岁";
                    },
                    bindRegionChange: function(t, e) {
                        var n = t.label.split("-");
                        this.form.areaRetention.province = n[0], this.form.areaRetention.city = n[1];
                    },
                    bindTime: function(t, e) {
                        this.form[e].date = t;
                    },
                    question_1_change: function(t) {
                        var e = this.question_1_options, n = t.detail.value;
                        if (n) {
                            this.form.symptoms = n;
                            for (var i = 0, a = e.length; i < a; ++i) {
                                var o = e[i];
                                n.includes(o.value) ? this.$set(o, "checked", !0) : this.$set(o, "checked", !1);
                            }
                        }
                    },
                    goBack: function() {
                        t.switchTab({
                            url: "/pages/epidemic/returnSchool/returnSchool"
                        });
                    },
                    showToast: function() {
                        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "", n = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "none", i = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 1e3;
                        t.showToast({
                            title: e,
                            icon: n,
                            duration: i
                        });
                    }
                }
            };
            e.default = i;
        }).call(this, n(1).default);
    },
    195: function(t, e, n) {
        n.r(e);
        var i = n(196), a = n.n(i);
        for (var o in i) "default" !== o && function(t) {
            n.d(e, t, function() {
                return i[t];
            });
        }(o);
        e.default = a.a;
    },
    196: function(t, e, n) {}
}, [ [ 189, "common/runtime", "common/vendor" ] ] ]);