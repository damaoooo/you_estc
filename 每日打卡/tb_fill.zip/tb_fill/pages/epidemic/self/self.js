(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/epidemic/self/self" ], {
    231: function(n, e, t) {
        (function(n) {
            function e(n) {
                return n && n.__esModule ? n : {
                    default: n
                };
            }
            t(4), t(5);
            e(t(2));
            n(e(t(232)).default);
        }).call(this, t(1).createPage);
    },
    232: function(n, e, t) {
        t.r(e);
        var a = t(233), r = t(235);
        for (var u in r) "default" !== u && function(n) {
            t.d(e, n, function() {
                return r[n];
            });
        }(u);
        t(237);
        var o = t(14), i = Object(o.default)(r.default, a.render, a.staticRenderFns, !1, null, "396a1c2c", null);
        i.options.__file = "src/pages/epidemic/self/self.vue", e.default = i.exports;
    },
    233: function(n, e, t) {
        t.r(e);
        var a = t(234);
        t.d(e, "render", function() {
            return a.render;
        }), t.d(e, "staticRenderFns", function() {
            return a.staticRenderFns;
        });
    },
    234: function(n, e, t) {
        t.r(e), t.d(e, "render", function() {
            return a;
        }), t.d(e, "staticRenderFns", function() {
            return r;
        });
        var a = function() {
            var n = this, e = n.$createElement;
            n._self._c;
        }, r = [];
        a._withStripped = !0;
    },
    235: function(n, e, t) {
        t.r(e);
        var a = t(236), r = t.n(a);
        for (var u in a) "default" !== u && function(n) {
            t.d(e, n, function() {
                return a[n];
            });
        }(u);
        e.default = r.a;
    },
    236: function(n, e, t) {
        (function(n) {
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.default = void 0;
            var a = {
                name: "self",
                components: {
                    myTab: function() {
                        return t.e("components/my-tab/index").then(t.bind(null, 290));
                    }
                },
                data: function() {
                    return {
                        user: {
                            avatarUrl: null,
                            name: null,
                            college: null,
                            className: null,
                            major: null,
                            sn: null
                        },
                        hasUserInfo: !1,
                        backCount: 0,
                        registerCount: 0,
                        leaveCount: 0
                    };
                },
                watch: {
                    user: function(n, e) {
                        null !== n.name || null !== n.avatarUrl || null !== n.college ? this.hasUserInfo = !0 : this.hasUserInfo = !1;
                    }
                },
                onShow: function() {
                    this.user = Object.assign({}, JSON.parse(n.getStorageSync("userInfo"))), null !== this.user.name || null !== this.user.avatarUrl || null !== this.user.college ? this.hasUserInfo = !0 : this.hasUserInfo = !1;
                },
                methods: {
                    getLeaveStatistics: function() {
                        var n = this;
                        this.$fly.post("./api/student/getLeaveStatistics").then(function(e) {
                            e.status && (n.backCount = e.data.backCount, n.leaveCount = e.data.leaveCount, n.registerCount = e.data.registerCount);
                        });
                    },
                    goEveryDayList: function() {
                        n.navigateTo({
                            url: "/pages/epidemic/everyDayList/everyDayList"
                        });
                    },
                    goLeaveHistory: function() {
                        n.navigateTo({
                            url: "/pages/main/leaveSchool/leaveSchoolHistory"
                        });
                    },
                    goUnbind: function() {
                        n.navigateTo({
                            url: "/pages/main/unbind/unbind"
                        });
                    },
                    goWaitBack: function() {
                        n.navigateTo({
                            url: "/pages/main/leaveSchool/waitBack"
                        });
                    },
                    goHealthCard: function() {
                        n.navigateTo({
                            url: "/pages/epidemic/returnSchool/healthCard?readyOnly=true"
                        });
                    }
                }
            };
            e.default = a;
        }).call(this, t(1).default);
    },
    237: function(n, e, t) {
        t.r(e);
        var a = t(238), r = t.n(a);
        for (var u in a) "default" !== u && function(n) {
            t.d(e, n, function() {
                return a[n];
            });
        }(u);
        e.default = r.a;
    },
    238: function(n, e, t) {}
}, [ [ 231, "common/runtime", "common/vendor" ] ] ]);