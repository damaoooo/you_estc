(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/epidemic/studentRegister/studentRegister" ], {
    162: function(t, e, n) {
        (function(t) {
            function e(t) {
                return t && t.__esModule ? t : {
                    default: t
                };
            }
            n(4), n(5);
            e(n(2));
            t(e(n(163)).default);
        }).call(this, n(1).createPage);
    },
    163: function(t, e, n) {
        n.r(e);
        var i = n(164), o = n(166);
        for (var a in o) "default" !== a && function(t) {
            n.d(e, t, function() {
                return o[t];
            });
        }(a);
        n(169);
        var r = n(14), s = Object(r.default)(o.default, i.render, i.staticRenderFns, !1, null, "20fb772a", null);
        s.options.__file = "src/pages/epidemic/studentRegister/studentRegister.vue", e.default = s.exports;
    },
    164: function(t, e, n) {
        n.r(e);
        var i = n(165);
        n.d(e, "render", function() {
            return i.render;
        }), n.d(e, "staticRenderFns", function() {
            return i.staticRenderFns;
        });
    },
    165: function(t, e, n) {
        n.r(e), n.d(e, "render", function() {
            return i;
        }), n.d(e, "staticRenderFns", function() {
            return o;
        });
        var i = function() {
            var t = this, e = t.$createElement;
            t._self._c;
        }, o = [];
        i._withStripped = !0;
    },
    166: function(t, e, n) {
        n.r(e);
        var i = n(167), o = n.n(i);
        for (var a in i) "default" !== a && function(t) {
            n.d(e, t, function() {
                return i[t];
            });
        }(a);
        e.default = o.a;
    },
    167: function(t, e, n) {
        (function(t) {
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.default = void 0;
            var i = new (n(168))({
                key: "OEABZ-I2G6D-G7N4N-HHBGB-CFZ35-VUBV5"
            }), o = {
                name: "student-register",
                components: {},
                data: function() {
                    return {
                        detailId: "",
                        Areaaddress: "",
                        info: {
                            healthStatus: 0,
                            locationStatus: 0,
                            registerStatus: 0
                        },
                        schoolLocation: [ {
                            latitudeTarget: 30.675749,
                            longitudeTarget: 104.100548,
                            r: 540
                        }, {
                            latitudeTarget: 30.749205,
                            longitudeTarget: 103.930525,
                            r: 935
                        } ],
                        earthL: 40030173
                    };
                },
                onLoad: function() {
                    this.init();
                },
                onShow: function() {
                    this.getRegistrationArrive(), this.getLocation();
                },
                onHide: function() {
                    this.Areaaddress = "", this.info.registerStatus = 0;
                },
                methods: {
                    init: function() {
                        var t = this;
                        this.schoolLocation.map(function(e) {
                            var n = t.earthL * Math.cos(e.latitudeTarget);
                            e.latitudeR = parseInt(360 * e.r / t.earthL * 1e4) / 1e4, e.longitudeR = parseInt(360 * e.r / n * 1e4) / 1e4;
                        });
                    },
                    getRegistrationArrive: function() {
                        var t = this;
                        this.$fly.post("./api/wx/getRegistrationArrive").then(function(e) {
                            e.status ? (t.detailId = e.data.detailId, t.info.registerStatus = e.data.status, 
                            t.info.healthStatus = 2 === e.data.status ? 1 : 0) : t.showToast(e.message || "获取数据失败");
                        });
                    },
                    commitRegistrationArrive: function() {
                        var t = this;
                        this.$fly.post("./api/wx/commitRegistrationArrive", {
                            currentAddress: this.Areaaddress,
                            detailId: this.detailId
                        }).then(function(e) {
                            e.status ? t.getRegistrationArrive() : t.showToast(e.message || "获取数据失败");
                        });
                    },
                    getLocation: function() {
                        var e = this;
                        t.getLocation({
                            type: "gcj02",
                            success: function(n) {
                                e.info.locationStatus = 0, e.schoolLocation.map(function(t, i) {
                                    e.GetDistance(t.latitudeTarget, t.longitudeTarget, n.latitude, n.longitude) <= t.r && (e.info.locationStatus = 1);
                                }), i.reverseGeocoder({
                                    location: {
                                        latitude: n.latitude,
                                        longitude: n.longitude
                                    },
                                    success: function(n) {
                                        console.log("mapSuccess", n), t.showToast({
                                            title: "位置信息:" + n.result.address,
                                            icon: "none"
                                        }, 1e3), e.Areaaddress = n.result.address;
                                    },
                                    complete: function(t) {
                                        console.log("complete", t);
                                    },
                                    fail: function(e) {
                                        t.showToast({
                                            title: "获取位置信息失败！",
                                            icon: "none"
                                        }, 1e3), console.log("mapFail11", e);
                                    }
                                });
                            },
                            fail: function(e) {
                                console.log("localFail", e), t.showToast({
                                    title: "获取定位失败，请打开定位，重新进入！",
                                    icon: "none"
                                }, 1e3);
                            }
                        });
                    },
                    showToast: function() {
                        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "", n = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 1e3, i = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : "none";
                        t.showToast({
                            title: e,
                            icon: i,
                            duration: n
                        });
                    },
                    GetDistance: function(t, e, n, i) {
                        function o(t) {
                            return t * Math.PI / 180;
                        }
                        var a = o(t), r = o(n), s = a - r, u = o(e) - o(i), c = 2 * Math.asin(Math.sqrt(Math.pow(Math.sin(s / 2), 2) + Math.cos(a) * Math.cos(r) * Math.pow(Math.sin(u / 2), 2)));
                        return c *= 6378.137, c = Math.round(1e4 * c) / 1e4, c *= 1e3;
                    }
                }
            };
            e.default = o;
        }).call(this, n(1).default);
    },
    169: function(t, e, n) {
        n.r(e);
        var i = n(170), o = n.n(i);
        for (var a in i) "default" !== a && function(t) {
            n.d(e, t, function() {
                return i[t];
            });
        }(a);
        e.default = o.a;
    },
    170: function(t, e, n) {}
}, [ [ 162, "common/runtime", "common/vendor" ] ] ]);