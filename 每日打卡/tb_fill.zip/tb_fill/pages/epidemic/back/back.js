(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/epidemic/back/back" ], {
    205: function(e, t, n) {
        (function(e) {
            function t(e) {
                return e && e.__esModule ? e : {
                    default: e
                };
            }
            n(4), n(5);
            t(n(2));
            e(t(n(206)).default);
        }).call(this, n(1).createPage);
    },
    206: function(e, t, n) {
        n.r(t);
        var a = n(207), i = n(209);
        for (var o in i) "default" !== o && function(e) {
            n.d(t, e, function() {
                return i[e];
            });
        }(o);
        n(211), n(213);
        var r = n(14), l = Object(r.default)(i.default, a.render, a.staticRenderFns, !1, null, "04b2f50c", null);
        l.options.__file = "src/pages/epidemic/back/back.vue", t.default = l.exports;
    },
    207: function(e, t, n) {
        n.r(t);
        var a = n(208);
        n.d(t, "render", function() {
            return a.render;
        }), n.d(t, "staticRenderFns", function() {
            return a.staticRenderFns;
        });
    },
    208: function(e, t, n) {
        n.r(t), n.d(t, "render", function() {
            return a;
        }), n.d(t, "staticRenderFns", function() {
            return i;
        });
        var a = function() {
            var e = this, t = e.$createElement, n = (e._self._c, e.__map(e.form.travelPlanInfo, function(t, n) {
                var a = e.__map(e.form.travelPlanInfo[n].travelInfo, function(t, a) {
                    var i = e.getTrafficIJ(n, a);
                    return {
                        $orig: e.__get_orig(t),
                        m0: i
                    };
                });
                return {
                    $orig: e.__get_orig(t),
                    l0: a
                };
            }));
            e.$mp.data = Object.assign({}, {
                $root: {
                    l1: n
                }
            });
        }, i = [];
        a._withStripped = !0;
    },
    209: function(e, t, n) {
        n.r(t);
        var a = n(210), i = n.n(a);
        for (var o in a) "default" !== o && function(e) {
            n.d(t, e, function() {
                return a[e];
            });
        }(o);
        t.default = i.a;
    },
    210: function(e, t, n) {
        (function(e) {
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var a = function(e) {
                return e && e.__esModule ? e : {
                    default: e
                };
            }(n(24)), i = {
                name: "back",
                components: {
                    ruiDatePicker: function() {
                        return Promise.all([ n.e("common/vendor"), n.e("components/rattenking-dtpicker/rattenking-dtpicker") ]).then(n.bind(null, 273));
                    },
                    cityPicker: function() {
                        return Promise.all([ n.e("common/vendor"), n.e("components/mpvue-citypicker/mpvueCityPicker") ]).then(n.bind(null, 280));
                    },
                    myTab: function() {
                        return n.e("components/my-tab/index").then(n.bind(null, 290));
                    }
                },
                data: function() {
                    return {
                        readOnly: !0,
                        lastUpdate: "无",
                        pickerValueDefault: [ 0, 0, 0 ],
                        area: "",
                        detail: "",
                        travelRange: [ "汽车（自驾）", "汽车（长途大巴）", "汽车（出租车）", "地铁", "火车", "动车/高铁", "飞机", "轮船", "其他" ],
                        form: {
                            id: null,
                            goPlace: "",
                            isTravel: 1,
                            reachTime: "",
                            travelPlanInfo: [ {
                                planInfo: "已进行",
                                travelInfo: [ {
                                    destination: "",
                                    endTime: "",
                                    goPlace: "",
                                    startTime: "",
                                    trafficInfo: "",
                                    vehicleType: null
                                } ]
                            } ],
                            vehicle: [ {
                                destination: "",
                                endTime: "",
                                goPlace: "",
                                startTime: "",
                                trafficInfo: "",
                                vehicleType: null
                            } ]
                        }
                    };
                },
                onShow: function() {
                    this.getDetail();
                },
                methods: {
                    getTrafficI: function(e) {
                        var t = this.form.vehicle[e].vehicleType;
                        return t ? this.travelRange[parseInt(t) - 1] : "";
                    },
                    getTrafficIJ: function(e, t) {
                        var n = this.form.travelPlanInfo[e].travelInfo[t].vehicleType;
                        return n ? this.travelRange[parseInt(n) - 1] : "";
                    },
                    noOpenClick: function() {
                        e.showToast({
                            title: "暂未开放返校登记填写",
                            icon: "none",
                            duration: 1e3
                        });
                    },
                    formatDateF: function(e) {
                        return e ? (0, a.default)(e).format("YYYY-MM-DD HH:mm") : "";
                    },
                    checkForm: function() {
                        var t = [ {
                            key: "vehicleType",
                            msg: "交通工具"
                        }, {
                            key: "trafficInfo",
                            msg: "交通信息"
                        }, {
                            key: "startTime",
                            msg: "开始时间"
                        }, {
                            key: "endTime",
                            msg: "结束时间"
                        }, {
                            key: "goPlace",
                            msg: "行程开始点"
                        }, {
                            key: "destination",
                            msg: "行程结束点"
                        } ];
                        if (1 == this.form.isTravel) for (var n = 0; n < this.form.travelPlanInfo.length; n++) for (var a = 0; a < this.form.travelPlanInfo[n].travelInfo.length; a++) {
                            for (var i = this.form.travelPlanInfo[n].travelInfo[a], o = 0; o < t.length; o++) if (!i[t[o].key]) return e.showToast({
                                title: "请填写完整第".concat(n + 1, "个出行计划，第").concat(a + 1, "个交通工具，").concat(t[o].msg, "字段"),
                                icon: "none",
                                duration: 1e3
                            }), !1;
                            var r = this.timeCheck(i.startTime, i.endTime, this.form.travelPlanInfo[n].planInfo, n, a);
                            if (r) return e.showToast({
                                title: r,
                                icon: "none",
                                duration: 1e3
                            }), !1;
                        }
                        return !0;
                    },
                    timeCheck: function(e, t, n, i, o) {
                        var r = Date.now(), l = null;
                        return e = (0, a.default)(e).valueOf(), t = (0, a.default)(t).valueOf(), "已进行" === n ? e >= r && (l = "第".concat(i + 1, "个出行计划，第").concat(o + 1, "个交通工具，开始时间应早于当前时间")) : e <= r && (l = "第".concat(i + 1, "个出行计划，第").concat(o + 1, "个交通工具，开始时间应晚于当前时间")), 
                        l || e >= t && (l = "第".concat(i + 1, "个出行计划，第").concat(o + 1, "个交通工具，开始时间应晚于结束时间")), 
                        l;
                    },
                    submit: function() {
                        var t = this;
                        if (this.checkForm()) {
                            this.form.isTravel = 1;
                            var n = JSON.parse(JSON.stringify(this.form)), a = !!n.id;
                            a || delete n.id, 0 == this.form.isTravel && delete n.travelPlanInfo, this.area && 3 == this.area.length && (n.goPlace = this.area.split("-").join(";") + ";" + this.detail), 
                            this.$fly.post(a ? "./updateBackSchoolInfo" : "./backSchoolInfoReg", n).then(function(n) {
                                n.status ? (e.showToast({
                                    title: "提交成功",
                                    icon: {
                                        none: !0
                                    },
                                    duration: 1e3
                                }), setTimeout(function() {
                                    t.getDetail();
                                }, 1e3)) : e.showToast({
                                    title: n.message,
                                    icon: "none",
                                    duration: 1e3
                                });
                            });
                        }
                    },
                    getDetail: function() {
                        var e = this;
                        this.$fly.get("./getBackSchoolInfo").then(function(t) {
                            t.status && t.data.id && (e.form.id = t.data.id, e.lastUpdate = t.data.updateTime ? (0, 
                            a.default)(t.data.updateTime).format("YYYY-MM-DD HH:mm") : "无", t.data.goPlace = t.data.goPlace.split(";"), 
                            t.data.goPlace && 4 == t.data.goPlace.length && (e.detail = t.data.goPlace[3], e.area = t.data.goPlace[0] + "-" + t.data.goPlace[1] + "-" + t.data.goPlace[2]), 
                            e.form.reachTime = t.data.reachTime, e.form.isTravel = t.data.isTravel, t.data.vehicle && (e.form.vehicle = t.data.vehicle), 
                            t.data.travelPlanInfo && t.data.travelPlanInfo.length > 0 && (e.form.travelPlanInfo = t.data.travelPlanInfo, 
                            e.form.travelPlanInfo.map(function(e) {
                                e.travelInfo.map(function(e) {
                                    e.startTime && (e.startTime = (0, a.default)(e.startTime).format("YYYY-MM-DD HH:mm")), 
                                    e.endTime && (e.endTime = (0, a.default)(e.endTime).format("YYYY-MM-DD HH:mm"));
                                });
                            })));
                        });
                    },
                    bindRegionChange: function(e, t, n, a) {
                        this.form.travelPlanInfo[t].travelInfo[n][a] = e.label.replace(/-/g, "");
                    },
                    bindReachTime: function(e) {
                        this.form.reachTime = e;
                    },
                    vehicleChange: function(e, t) {
                        this.form.vehicle[t].vehicleType = parseInt(e.detail.value) + 1;
                    },
                    bindVehicleStartTime: function(e, t) {
                        this.form.vehicle[t].startTime = e;
                    },
                    bindVehicleEndTime: function(e, t) {
                        this.form.vehicle[t].endTime = e;
                    },
                    vehicleAdd: function() {
                        this.noOpenClick();
                    },
                    vehicleDelete: function(e) {
                        this.form.vehicle.splice(e, 1);
                    },
                    radioChange: function(e) {
                        this.form.isTravel = e.detail.value;
                    },
                    isTravelChange: function(e, t) {
                        this.form.travelPlanInfo[t].planInfo = e.detail.value;
                    },
                    travelInfoChange: function(e, t, n) {
                        this.form.travelPlanInfo[t].travelInfo[n].vehicleType = parseInt(e.detail.value) + 1;
                    },
                    bindTravelStartTime: function(e, t, n) {
                        this.form.travelPlanInfo[t].travelInfo[n].startTime = e;
                    },
                    bindTravelEndTime: function(e, t, n) {
                        this.form.travelPlanInfo[t].travelInfo[n].endTime = e;
                    },
                    addTravel: function() {
                        this.form.travelPlanInfo.push({
                            planInfo: "已进行",
                            travelInfo: [ {
                                destination: "",
                                endTime: "",
                                goPlace: "",
                                startTime: "",
                                trafficInfo: "",
                                vehicleType: null
                            } ]
                        });
                    },
                    deleteTravel: function(e) {
                        this.form.travelPlanInfo.splice(e, 1);
                    },
                    addTravelInfo: function(e) {
                        this.form.travelPlanInfo[e].travelInfo.push({
                            destination: "",
                            endTime: "",
                            goPlace: "",
                            startTime: "",
                            trafficInfo: "",
                            vehicleType: null
                        });
                    },
                    deleteTravelInfo: function(e, t) {
                        this.form.travelPlanInfo[e].travelInfo.splice(t, 1);
                    }
                }
            };
            t.default = i;
        }).call(this, n(1).default);
    },
    211: function(e, t, n) {
        n.r(t);
        var a = n(212), i = n.n(a);
        for (var o in a) "default" !== o && function(e) {
            n.d(t, e, function() {
                return a[e];
            });
        }(o);
        t.default = i.a;
    },
    212: function(e, t, n) {},
    213: function(e, t, n) {
        n.r(t);
        var a = n(214), i = n.n(a);
        for (var o in a) "default" !== o && function(e) {
            n.d(t, e, function() {
                return a[e];
            });
        }(o);
        t.default = i.a;
    },
    214: function(e, t, n) {}
}, [ [ 205, "common/runtime", "common/vendor" ] ] ]);